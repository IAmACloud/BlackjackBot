#include <std_msgs/Header.h>
struct MovementControl {
    std_msgs::Header header;
    std::string mode;
};

