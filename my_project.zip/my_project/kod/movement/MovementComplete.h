#ifndef MOVEMENT_COMPLETE_H
#define MOVEMENT_COMPLETE_H

#include <std_msgs/Header.h>

namespace msg {

struct MovementComplete {
  std_msgs::Header header;
  bool complete;
};

}  // namespace msg

#endif

